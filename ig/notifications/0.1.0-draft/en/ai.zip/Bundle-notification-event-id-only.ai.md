# Notification: event-notification, id-only - Twiin Notifications v0.1.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Notification: event-notification, id-only**

## Example Bundle: Notification: event-notification, id-only



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "notification-event-id-only",
  "meta" : {
    "profile" : ["https://fhir.twiin.nl/ig/notifications/StructureDefinition/twiin-subscription-notification"]
  },
  "type" : "history",
  "entry" : [{
    "fullUrl" : "urn:uuid:c3a5d8f1-9b2e-4d67-8a4c-5e1f7b9d2a36",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "notification-event-id-only-status",
      "meta" : {
        "profile" : ["https://fhir.twiin.nl/ig/notifications/StructureDefinition/twiin-subscription-status"]
      },
      "parameter" : [{
        "name" : "subscription",
        "valueReference" : {
          "reference" : "https://sender.example.org/fhir/Subscription/7f3e9a2c-5d18-4b6f-9c3a-8e2d4f6b1a59"
        }
      },
      {
        "name" : "topic",
        "valueCanonical" : "https://example.org/fhir/SubscriptionTopic/task-status-change"
      },
      {
        "name" : "status",
        "valueCode" : "active"
      },
      {
        "name" : "type",
        "valueCode" : "event-notification"
      },
      {
        "name" : "notification-event",
        "part" : [{
          "name" : "event-number",
          "valueString" : "42"
        },
        {
          "name" : "timestamp",
          "valueInstant" : "2026-07-16T09:15:00Z"
        },
        {
          "name" : "focus",
          "valueReference" : {
            "reference" : "https://sender.example.org/fhir/Task/5f2f9a4e-8c1d-4b6e-9d3a-7c0e2f4b8a1d"
          }
        }]
      }]
    },
    "request" : {
      "method" : "GET",
      "url" : "https://sender.example.org/fhir/Subscription/7f3e9a2c-5d18-4b6f-9c3a-8e2d4f6b1a59/$status"
    },
    "response" : {
      "status" : "200"
    }
  },
  {
    "fullUrl" : "https://sender.example.org/fhir/Task/5f2f9a4e-8c1d-4b6e-9d3a-7c0e2f4b8a1d",
    "request" : {
      "method" : "PUT",
      "url" : "Task/5f2f9a4e-8c1d-4b6e-9d3a-7c0e2f4b8a1d"
    },
    "response" : {
      "status" : "200"
    }
  }]
}

```
