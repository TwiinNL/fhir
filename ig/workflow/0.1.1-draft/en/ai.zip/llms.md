# nl.twiin.fhir.r4.workflow#0.1.1-draft: Twiin Workflow(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Artifacts overview](artifacts-overview.md)
* [Requirements not expressed in artifacts](requirements-not-in-artifacts.md)
* [Installing dependencies](installing-dependencies.md)

## Resources

### CodeSystems

* [TA Workflow Codes](CodeSystem-ta-workflow.md)

### ValueSets

* [TA Workflow Business Status](ValueSet-ta-workflow-business-status.md)
* [TA Workflow Status Reason](ValueSet-ta-workflow-status-reason.md)
* [TA Workflow Task Code](ValueSet-ta-workflow-task-code.md)

### Resource Profiles

* [Twiin Authorization Cancellation Request Task](StructureDefinition-twiin-authorization-cancellation-request-task.md)
* [Twiin Cancellation Request Task](StructureDefinition-twiin-cancellation-request-task.md)
* [Twiin Coordination Task](StructureDefinition-twiin-coordination-task.md)
* [Twiin Workflow ServiceRequest](StructureDefinition-twiin-workflow-servicerequest.md)
* [Twiin Workflow Subscription](StructureDefinition-twiin-workflow-subscription.md)

### CapabilityStatements

* [Twiin Workflow Placer Server](CapabilityStatement-twiin-workflow-placer-server.md)

### ImplementationGuides

* [Twiin Workflow](ImplementationGuide-nl.twiin.fhir.r4.workflow.md)

### Examples

* [3f6a2b8c-1d4e-4f7a-9b2c-5e8d1a7c4f90 (Patient)](Patient-3f6a2b8c-1d4e-4f7a-9b2c-5e8d1a7c4f90.md)
* [0b7c5d0e-6f3a-4c2b-9e1d-8a4f2c6b3d75 (ServiceRequest)](ServiceRequest-0b7c5d0e-6f3a-4c2b-9e1d-8a4f2c6b3d75.md)
* [1e8b4c6d-3f7a-4b2e-9d5c-8a1f6e3b7c29 (Subscription)](Subscription-1e8b4c6d-3f7a-4b2e-9d5c-8a1f6e3b7c29.md)
* [5b9d3e7f-1a2c-4f6e-8d4b-9e2a7c1f3b56 (Task)](Task-5b9d3e7f-1a2c-4f6e-8d4b-9e2a7c1f3b56.md)
* [6d2e9f41-8b3c-4a7d-b5e2-1c9f7a3d8e64 (Task)](Task-6d2e9f41-8b3c-4a7d-b5e2-1c9f7a3d8e64.md)
* [9c4a1f8e-7d3b-4e2a-b6f9-3a8e5d2c7b14 (Task)](Task-9c4a1f8e-7d3b-4e2a-b6f9-3a8e5d2c7b14.md)
* [a41c7e2b-5f9d-4e3a-8c6b-2d7f1e9a5b38 (Task)](Task-a41c7e2b-5f9d-4e3a-8c6b-2d7f1e9a5b38.md)
* [c8e3d5a7-2b4f-4d9e-a1c6-7f3b8e2d4a91 (Task)](Task-c8e3d5a7-2b4f-4d9e-a1c6-7f3b8e2d4a91.md)
* [e2f7a9c1-4d6b-4b8e-9a3f-6c1d5e8b2a47 (Task)](Task-e2f7a9c1-4d6b-4b8e-9a3f-6c1d5e8b2a47.md)
