# Artifacts overview - Twiin Workflow v0.4.0-draft

* [**Table of Contents**](toc.md)
* **Artifacts overview**

## Artifacts overview

This page is informative. It lists the artifacts in this guide and the section of TA Workflow each one belongs to. The requirements themselves are in the TA.

### Profiles

| | | |
| :--- | :--- | :--- |
| [Twiin Coordination Task](StructureDefinition-twiin-coordination-task.md) | `coordination-task`(COW IG 1.0.0-ballot) | Summary of the profiles → Coordination Task; Coordination Task; Status of the Coordination Task; Patient context and readability; Type of work on the Task; Sharing additional content; Search parameters |
| [Twiin Cancellation Request Task](StructureDefinition-twiin-cancellation-request-task.md) | `cancellation-request-task`(COW IG 1.0.0-ballot) | Summary of the profiles → Cancellation Request Task; Cancellation Request Task |
| [Twiin Authorization Cancellation Request Task](StructureDefinition-twiin-authorization-cancellation-request-task.md) | `Task`(FHIR R4) | Summary of the profiles → Authorization Cancellation Request Task; Cancellation by the Fulfiller |
| [Twiin Workflow ServiceRequest](StructureDefinition-twiin-workflow-servicerequest.md) | `ServiceRequest`(FHIR R4) | Summary of the profiles → ServiceRequest; Request; Patient context and readability.`priority`is mustSupport. |
| [Twiin Workflow Subscription](StructureDefinition-twiin-workflow-subscription.md) | `twiin-subscription`(Twiin Notifications 0.2.0-draft) | Subscription |

Task.owner and Task.location refer to a HealthcareService and a Location, with the type and a complete identifier (system, value and the identifier of its assigner) required. That they are profiled by GF Addressing is not expressed in the artifacts of this guide (see [Requirements not expressed in artifacts](requirements-not-in-artifacts.md)). The invariant `twiin-aid-1` excludes an assigner identified by a KvK number; the profiles do not fix the system of the assigner. The URA is always identified with the system `http://fhir.nl/fhir/NamingSystem/ura`, on the assigner as on Task.requester, as in GF Addressing.

COW IG defines no profile for the Authorization Cancellation Request Task. Its requester is the Fulfiller as an organization, identified by its URA, as its owner is the Placer: FHIR R4 does not allow Task.requester to refer to a HealthcareService (TA section Summary of the profiles → Authorization Cancellation Request Task).

Some constraints interpret the TA:

* Task.code of the Authorization Cancellation Request Task ("fixed to abort") and Task.input.type are expressed as patterns, as COW IG does for the Cancellation Request Task.
* The entries with type `available-resource` and `available-query` on the Coordination Task are optional slices that fix the value type (TA section Sharing additional content). The slice `informationRequest` (type `information-request`) does not constrain `value[x]`, since the TA does not fix the form of the request.
* `twiin-wsub-1` checks the form `owner:identifier=[system]|[value]` or `owner-assigner=[system]|[value]` of the filter; it cannot check that the identifier is that of a HealthcareService or the URA of an organization.
* `twiin-task-1` (statusReason.text when statusReason is populated) applies to all three Task profiles, as in the three tables of the TA.

### Invariants

| | | | |
| :--- | :--- | :--- | :--- |
| `twiin-ct-1` | error | Coordination Task | The statuses draft, ready and on-hold are not used |
| `twiin-ct-2` | error | Coordination Task | statusReason not-selected only when the status is cancelled |
| `twiin-ct-3` | error | Coordination Task | businessStatus selected implies code fulfill and for populated |
| `twiin-ct-5` | warning | Coordination Task | statusReason when the status is cancelled |
| `twiin-ct-6` | warning | Coordination Task | for.identifier is not populated |
| `twiin-ct-7` | error | Coordination Task | status in-progress or completed implies code fulfill |
| `twiin-ct-8` | error | Coordination Task | statusReason when the status is rejected or failed |
| `twiin-ct-9` | error | Coordination Task | statusReason.text when businessStatus is awaiting-information |
| `twiin-crt-1` | error | Cancellation Request Task | status requested, accepted, rejected, cancelled or entered-in-error |
| `twiin-acrt-1` | error | Authorization Cancellation Request Task | status requested, accepted or rejected |
| `twiin-task-1` | warning | all Task profiles | statusReason.text when statusReason is populated |
| `twiin-aid-1` | error | Coordination Task, Cancellation Request Task | The assigner of the identifier of a HealthcareService or Location is not a KvK number |
| `twiin-sr-1` | error | ServiceRequest | subject is not masked with data-absent-reason |
| `twiin-wsub-1` | error | Subscription | Filter of the form`owner:identifier=[system]|[value]`or`owner-assigner=[system]|[value]` |

### Terminology

| | |
| :--- | :--- |
| [TA Workflow Codes](CodeSystem-ta-workflow.md) | Codes of this TA |
| [TA Workflow Task Code](ValueSet-ta-workflow-task-code.md) | Codes of this TA |

### Search parameter

| | |
| :--- | :--- |
| [Task owner-assigner](SearchParameter-owner-assigner.md) | Search parameters; Subscription |

### Capability statement

| | |
| :--- | :--- |
| [Twiin Workflow Placer Server](CapabilityStatement-twiin-workflow-placer-server.md) | Placer server capabilities; Concurrent writes; Search parameters |

The capability statement imports the Twiin Subscription Server of TA Notifications for Subscription. Support for the modifier `:identifier`, and that create on Task is only for the Authorization Cancellation Request Task, are stated in documentation, because a CapabilityStatement has no element for them.

### Examples

| | |
| :--- | :--- |
| [ServiceRequest: transfer of care](ServiceRequest-0b7c5d0e-6f3a-4c2b-9e1d-8a4f2c6b3d75.md) | Request; Patient context and readability |
| [ServiceRequest: no definition](ServiceRequest-a529d458-5bec-4d91-8ed8-f4fd5bb93720.md) | Request; Routing by the Fulfiller |
| [Patient](Patient-3f6a2b8c-1d4e-4f7a-9b2c-5e8d1a7c4f90.md) | Patient context and readability |
| [Coordination Task: candidate invited](Task-6d2e9f41-8b3c-4a7d-b5e2-1c9f7a3d8e64.md) | Multiple Fulfillers Pattern; Sharing additional content; Patient context and readability |
| [Coordination Task: candidate selected](Task-a41c7e2b-5f9d-4e3a-8c6b-2d7f1e9a5b38.md) | Multiple Fulfillers Pattern; Bidding |
| [Coordination Task: candidate not selected](Task-c8e3d5a7-2b4f-4d9e-a1c6-7f3b8e2d4a91.md) | Reason for cancelling a non-selected candidate |
| [Coordination Task: single Fulfiller, in progress](Task-e2f7a9c1-4d6b-4b8e-9a3f-6c1d5e8b2a47.md) | Single Fulfiller Pattern; Sharing additional content |
| [Coordination Task: single Fulfiller, awaiting information](Task-948d41c4-820f-49ed-bbb7-c15e6d7fc699.md) | Single Fulfiller Pattern; Business status |
| [Cancellation Request Task](Task-5b9d3e7f-1a2c-4f6e-8d4b-9e2a7c1f3b56.md) | Cancellation Request (After in-progress) |
| [Authorization Cancellation Request Task](Task-9c4a1f8e-7d3b-4e2a-b6f9-3a8e5d2c7b14.md) | Cancellation by the Fulfiller |
| [Subscription for a HealthcareService](Subscription-1e8b4c6d-3f7a-4b2e-9d5c-8a1f6e3b7c29.md) | Subscription |

The page [Example scenarios](example-scenarios.md) shows the main scenarios with their own instances. The page [Example: reselection](example-reselection.md) shows one scenario in the Multiple Fulfillers Pattern with its own instances. The page [Example: sharing additional content](example-sharing.md) shows how the Placer shares content in Task.input and how a candidate asks for information.

The examples are not taken from the TA, which contains none. Hosts, identifiers, the topic URL and the ActivityDefinition URL are invented; the type of work uses SNOMED CT 308292007, which the TA names as the code of eOverdracht.

